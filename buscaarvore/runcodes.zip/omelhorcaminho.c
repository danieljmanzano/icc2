#include <stdio.h>
#include <stdlib.h>

typedef struct no_ {
  int chave;
  struct no_ *esquerda, *direita;
} no;

no *novoNo(int chave) {
  no *NO = (no *)malloc(sizeof(no));
  if (!NO)
    return NULL;
  NO->chave = chave;
  NO->direita = NO->esquerda = NULL;
  return NO;
}

no *procuraNo(no *raiz, int chave) {
  if (!raiz) {
    printf("%d", -1);
    return raiz;
  }
  if (raiz->chave == chave) {
    printf("%d", raiz->chave);
    return raiz;
  }
  printf("%d ", raiz->chave);
  if (raiz->chave < chave) {
    return procuraNo(raiz->direita, chave);
  }
  return procuraNo(raiz->esquerda, chave);
}

no *inserirNo(no *raiz, int chave) {
  if (!raiz)
    return novoNo(chave);
  if (raiz->chave > chave)
    raiz->esquerda = inserirNo(raiz->esquerda, chave);
  else if (raiz->chave < chave)
    raiz->direita = inserirNo(raiz->direita, chave);
  return raiz;
}

int main(void) {
  int tamanho, elemento, alvo;
  scanf(" %d", &tamanho);
  scanf(" %d", &elemento);
  no *raiz = NULL;
  raiz = inserirNo(raiz, elemento);
  for (int i = 0; i < tamanho - 1; i++) {
    scanf(" %d", &elemento);
    inserirNo(raiz, elemento);
  }
  scanf(" %d", &alvo);
  procuraNo(raiz, alvo);
  return 0;
}
